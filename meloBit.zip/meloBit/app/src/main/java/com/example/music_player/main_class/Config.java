package com.example.music_player.main_class;

public class Config {

    public static final String APIAddress = "https://api-beta.melobit.com/v1/";
}
